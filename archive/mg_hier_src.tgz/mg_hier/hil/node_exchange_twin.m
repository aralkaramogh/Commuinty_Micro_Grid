function f = node_exchange_twin(lk, id, P)
% NODE_EXCHANGE_TWIN  Exchange function for one real node: talks to the board and
% runs the MATLAB twin on the same line; counts any difference (node_twin_count).
if strcmp(id, 'SB'), st = node_sb_init(); else, st = node_load_init(); end
    function reply = xch(line, seq)
        reply = node_link_exchange(lk, line, seq);
        if line(1) == 'L'
            [st, r] = node_load_step(st, node_lines('dec_L', line), P.node, P.sim.dt);
            ref = node_lines('enc_l', seq, r);
        else
            [st, r] = node_sb_step(st, node_lines('dec_B', line), P.node, P.bess);
            ref = node_lines('enc_b', seq, r);
        end
        node_twin_count('add', ~strcmp(reply, ref));
        if ~strcmp(reply, ref) && node_twin_count('get') <= 5
            fprintf('  %s tick %d differs\n    board: %s\n    twin : %s\n', id, seq, reply, ref);
        end
    end
f = @xch;
end
