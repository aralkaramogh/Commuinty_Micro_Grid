% RUN_HIL_NODES  Real node ESP32s in the loop (Stage A). Set PORTS: any node not
% listed runs as a virtual node (MATLAB twin). Every real reply is ALSO checked
% against the MATLAB twin fed with the same line, so you see at once whether the
% board behaves exactly like the simulation. Flash firmware_node/mg_node first
% (the same sketch on every board).
PORTS  = {'H1', 'COM14'; 'SB', 'COM16'};    % <- your boards (node id, COM port)
SCEN   = 'S11_demo_outage';                 % 1500 ticks
PACE_S = 0;                                 % > 0 = slow motion (seconds per tick)

root = fileparts(fileparts(mfilename('fullpath')));
for f = {'params','plant','nodes','main','comms','pi','sim','tests','tools','hil'}, addpath(fullfile(root, f{1})); end
P = hier_params(); S = define_scenarios_h(P); sc = S(strcmp({S.name}, SCEN));
node_id = [P.load_id, {'SB'}];
ex = cell(1, numel(node_id)); links = {}; node_twin_count('reset');
for r = 1:size(PORTS, 1)
    k = find(strcmp(node_id, PORTS{r, 1}));
    assert(~isempty(k), 'unknown node id %s', PORTS{r, 1});
    lk = node_link_open(PORTS{r, 2}, P); links{end+1} = lk; %#ok<SAGROW>
    ex{k} = node_exchange_twin(lk, node_id{k}, P);
end
cl = onCleanup(@() cellfun(@(l) delete(l.sp), links));
fprintf('Running %s with real nodes: %s (others virtual)\n', SCEN, strjoin(PORTS(:,1).', ', '));
t0 = tic;
R = run_hier(sc, P, struct('exchange', {ex}, 'progress_every', 60, 'pace_s', PACE_S));
fprintf('Done: %d ticks in %.0f s (%.0f ms per tick)\n', numel(R.L.t), toc(t0), 1000 * toc(t0) / numel(R.L.t));
[ok, msg] = check_h(R, P);
fprintf('Scenario rules: %s\n', string(ok)); if ~ok, fprintf('  - %s\n', msg{:}); end
fprintf('Real board replies identical to the MATLAB twin: %d of %d differed\n', node_twin_count('get'), node_twin_count('n'));
